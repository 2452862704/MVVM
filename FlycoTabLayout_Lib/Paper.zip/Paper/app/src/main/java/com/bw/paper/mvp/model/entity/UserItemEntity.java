package com.bw.paper.mvp.model.entity;

public class UserItemEntity {

    public String name;
    public boolean selFlag = false;
    public Class clazz;

    public UserItemEntity( String name,Class clazz){
        this.name = name;
        this.clazz = clazz;
    }

}
