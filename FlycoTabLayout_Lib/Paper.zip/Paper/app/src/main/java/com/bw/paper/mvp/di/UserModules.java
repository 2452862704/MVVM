package com.bw.paper.mvp.di;

import com.bw.paper.mvp.contract.UserContract;
import com.bw.paper.mvp.model.UserModel;

import dagger.Module;
import dagger.Provides;

@Module
public class UserModules {

    private UserContract.IUserView view;

    public UserModules(UserContract.IUserView view){
        this.view = view;
    }

    @Provides
    public UserContract.IUserView providerView(){
        return view;
    }

    @Provides
    public UserContract.IUserModel providerModel(UserModel model){
        return model;
    }

}
