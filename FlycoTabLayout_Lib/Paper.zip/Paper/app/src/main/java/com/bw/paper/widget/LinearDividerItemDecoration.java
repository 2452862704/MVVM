package com.bw.paper.widget;

import android.content.Context;

import com.yanyusong.y_divideritemdecoration.Y_Divider;
import com.yanyusong.y_divideritemdecoration.Y_DividerBuilder;
import com.yanyusong.y_divideritemdecoration.Y_DividerItemDecoration;

public class LinearDividerItemDecoration extends Y_DividerItemDecoration {

    private int size = 0;

    public LinearDividerItemDecoration(Context context) {
        super(context);
    }

    @Override
    public Y_Divider getDivider(int itemPosition) {
        Y_Divider divider = null;
        if (itemPosition==4){
            divider = new Y_DividerBuilder()
                    .setBottomSideLine(true, 0xff000000, 0, 0, 0)
                    .create();
        }else if (itemPosition==0){
            divider = new Y_DividerBuilder()
                    .setBottomSideLine(true, 0xff000000, 0, 0, 0)
                    .create();
        } else
            divider = new Y_DividerBuilder()
                    .setBottomSideLine(true, 0xffc1c1c1, 1, 0, 0)
                    .create();
        return divider;
    }
}
