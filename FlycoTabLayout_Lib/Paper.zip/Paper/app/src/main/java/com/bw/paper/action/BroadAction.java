package com.bw.paper.action;

public class BroadAction {
    //更新用户信息action
    public final static String UPDATEUSERACTION = "com.bw.paper.user";
}
