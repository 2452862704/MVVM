package com.bw.paper.test;

import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

public interface TestContract {

    interface TestViewImpl extends IView{
        void refresh();
    }

    interface TestModelImpl extends IModel{
        void request();
    }

}
