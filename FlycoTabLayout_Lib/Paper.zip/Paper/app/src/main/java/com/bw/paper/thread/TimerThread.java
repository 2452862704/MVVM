package com.bw.paper.thread;

import android.os.Handler;
import android.os.Message;

public class TimerThread extends Thread{

    private Handler handler;

    public TimerThread(Handler handler){
        this.handler = handler;
    }

    @Override
    public void run() {
        super.run();
        try {
            Thread.sleep(1500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        handler.sendEmptyMessage(0);
    }
}
