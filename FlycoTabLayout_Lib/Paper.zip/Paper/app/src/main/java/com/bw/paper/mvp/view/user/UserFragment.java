package com.bw.paper.mvp.view.user;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.bw.paper.App;
import com.bw.paper.R;
import com.bw.paper.action.BroadAction;
import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.view.BaseFragment;
import com.bw.paper.mvp.contract.UserContract;
import com.bw.paper.mvp.di.DaggerUserComponent;
import com.bw.paper.mvp.di.UserModules;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.mvp.model.entity.UserEntity;
import com.bw.paper.mvp.model.entity.UserItemEntity;
import com.bw.paper.mvp.model.entity.UserMenuEntity;
import com.bw.paper.mvp.presenter.UserPresenter;
import com.bw.paper.mvp.view.user.adapter.UserAdapter;
import com.bw.paper.mvp.view.user.adapter.UserMenuAdapter;
import com.bw.paper.utils.LogUtils;
import com.bw.paper.widget.LinearDividerItemDecoration;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import java.util.List;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class UserFragment extends BaseFragment<UserPresenter> implements UserContract.IUserView,
        OnItemChildClickListener,View.OnClickListener {

    private View menuView,timeLineView;
    private TextView user_name;
    private RecyclerView menu_rv;
    private RecyclerView user_rv;
    private UserAdapter adapter;
    private UserMenuAdapter menuAdapter;
    private UserBroadCast broadCast;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        broadCast = new UserBroadCast();
        IntentFilter filter = new IntentFilter();
        filter.addAction(BroadAction.UPDATEUSERACTION);
        getActivity().registerReceiver(broadCast,filter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(broadCast);
    }

    @Override
    public int bindLayout() {
        return R.layout.fragment_user;
    }

    @Override
    public void initView() {
        user_rv = f(R.id.user_rv);
        menuView = LayoutInflater.from(getContext()).inflate(R.layout.view_user_menu,null);
        user_name = menuView.findViewById(R.id.user_name);
        timeLineView = LayoutInflater.from(getContext()).inflate(R.layout.view_user_speed,null);
        menu_rv = menuView.findViewById(R.id.menu_rv);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(),4);
        gridLayoutManager.setOrientation(GridLayoutManager.VERTICAL);
        menu_rv.setLayoutManager(gridLayoutManager);
        menuAdapter = new UserMenuAdapter();
        menu_rv.setAdapter(menuAdapter);
        LinearLayoutManager manager = new LinearLayoutManager(getContext());
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        user_rv.setLayoutManager(manager);
        user_rv.addItemDecoration(new LinearDividerItemDecoration(getContext()));
        adapter = new UserAdapter();
        //添加头布局
        adapter.addHeaderView(menuView);
        adapter.addHeaderView(LayoutInflater.from(getContext()).inflate(R.layout.view_user_interval,null));
        adapter.addHeaderView(timeLineView);
        adapter.setOnItemChildClickListener(this);
        user_rv.setAdapter(adapter);
        user_name.setOnClickListener(this::onClick);
    }

    @Override
    public void initData() {
        p.initData();
        List<UserEntity>list = App.getInstance().getDaoSession().queryBuilder(UserEntity.class).list();
        if (list!=null){
            if (list.size()>0){
                UserEntity entity = list.get(0);
                refreshUser(entity);
            }
        }
    }

    @Override
    public void inject() {
        DaggerUserComponent.builder().userModules(
                new UserModules(this)).build().inject(this);
    }

    @Override
    public void refresh(BaseEntity entity) {

    }

    @Override
    public void refreshMenu(List<UserMenuEntity> menues) {
        menuAdapter.setNewInstance(menues);
    }

    @Override
    public void refreshItemes(List<UserItemEntity> itemes) {
        adapter.setNewInstance(itemes);
    }

    @Override
    public void onItemChildClick(@NonNull BaseQuickAdapter adapter, @NonNull View view, int position) {
        if (position == 1){
            UserItemEntity entity = (UserItemEntity) adapter.getData().get(position);
            entity.selFlag= !entity.selFlag;
            adapter.setData(position,entity);
        }
    }

    @Override
    public void onClick(View v) {
        startPage(LoginActivity.class);
    }

    //广播接收器接收到传递过来的数据刷新界面方法
    private void refreshUser(UserEntity entity){

//        entity.user_name
//        entity.user_integral积分等级
//          entity.user_img
        LogUtils.show("entity:"+(entity==null));
        user_name.setText(entity.user_name+"Lv"+entity.user_integral);
    }


    private class UserBroadCast extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(BroadAction.UPDATEUSERACTION)){
                UserEntity entity = (UserEntity) intent.getParcelableExtra("userValues");
                refreshUser(entity);
            }

        }
    }
}
