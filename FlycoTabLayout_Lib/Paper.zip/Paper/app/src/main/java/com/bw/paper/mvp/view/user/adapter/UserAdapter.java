package com.bw.paper.mvp.view.user.adapter;

import com.bw.paper.R;
import com.bw.paper.mvp.model.entity.UserItemEntity;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;

import org.jetbrains.annotations.NotNull;

public class UserAdapter extends BaseQuickAdapter<UserItemEntity, BaseViewHolder> {

    public UserAdapter() {
        super(R.layout.item_user_itemes);
        addChildClickViewIds(R.id.user_itemes_arrow_img);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, UserItemEntity userItemEntity) {
        baseViewHolder.setText(R.id.user_itemes_tv,userItemEntity.name);
        baseViewHolder.setImageResource(R.id.user_itemes_arrow_img,R.drawable.icon_pn_arrows);
        if (userItemEntity.name.equals("夜间模式")){
            if (userItemEntity.selFlag){
                baseViewHolder.setImageResource(R.id.user_itemes_arrow_img,R.drawable.new_on);
            }else{
                baseViewHolder.setImageResource(R.id.user_itemes_arrow_img,R.drawable.new_off);
            }
        }

    }
}
