package com.bw.paper.mvp.base.presenter;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

import io.reactivex.Observer;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

public abstract class BasePresenter <M extends IModel,V extends IView>
        implements IPresenter, Observer<BaseEntity> {

    protected M m;
    protected V v;
    protected CompositeDisposable compositeDisposable;
    public BasePresenter(M m,V v){
        this.m = m;
        this.v = v;
        compositeDisposable = new CompositeDisposable();
    }

    @Override
    public void onDestrory() {
        compositeDisposable.dispose();
        compositeDisposable.clear();
    }

    @Override
    public void onSubscribe(@NonNull Disposable d) {
        compositeDisposable.add(d);
        v.showDialog();
    }

    @Override
    public void onError(@NonNull Throwable e) {
        v.showMsg(e.getMessage());
    }

    @Override
    public void onComplete() {
        v.hideDialog();
    }
}
