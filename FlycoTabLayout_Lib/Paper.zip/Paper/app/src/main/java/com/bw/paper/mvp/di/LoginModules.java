package com.bw.paper.mvp.di;

import com.bw.paper.mvp.contract.LoginContract;
import com.bw.paper.mvp.model.LoginModel;

import dagger.Module;
import dagger.Provides;

@Module
public class LoginModules {

    private LoginContract.ILoginView view;
    public LoginModules(LoginContract.ILoginView view){
        this.view = view;
    }

    @Provides
    public LoginContract.ILoginView providerView(){
        return view;
    }

    @Provides
    public LoginContract.ILoginModel providerModel(LoginModel model){
        return model;
    }

}
