package com.bw.paper.test;

import android.view.View;
import android.widget.TextView;

import com.bw.paper.R;
import com.bw.paper.mvp.base.view.BaseActivity;
import com.bw.paper.test.di.DaggerTestComponent;
import com.bw.paper.test.di.Modeles;

public class TestActivity extends BaseActivity<TestPreenter>implements TestContract.TestViewImpl {
    @Override
    public View addStatusView() {
        return null;
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_main;
    }

    @Override
    public void initView() {
    }

    @Override
    public void initData() {

    }

    @Override
    public void inject() {
        DaggerTestComponent.builder().modeles(
                new Modeles(this)).build().inject(this);
    }

    @Override
    public void refresh() {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
