package com.bw.paper.mvp.model;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.BaseModel;
import com.bw.paper.mvp.contract.LoginContract;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.network.Api;
import com.bw.paper.network.ChangeFunction;
import com.bw.paper.network.HttpFactory;
import com.bw.paper.network.HttpType;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observable;
import okhttp3.RequestBody;

public class LoginModel extends BaseModel implements LoginContract.ILoginModel {

    @Inject
    public LoginModel(){}

    //登录接口请求
    //三方登录请求
    //注册接口请求
    @Override
    public Observable<BaseEntity> request(Map<String, Object> map) {
       //区分当前方法执行哪个接口的请求
        int code = (int) map.get("code");
        map.remove("code");
        if (code == HttpCode.LOGINCODE){
            //当前为登录接口逻辑使用
            //map->json字符串->生成requestbody
            RequestBody body = createBody(map);
            //根据在api中配置对应的服务器json返回值生成的bean类
            Observable<ResponseUserEntity> ob = HttpFactory.getInstance().factory(HttpType.TOKENSIGNTYPE).getRetrofit()
                    .create(Api.class).requestLogin(body);
            //对当前的异步任务进行转化
            return ob.map(new ChangeFunction<ResponseUserEntity>());
        }else if (code == HttpCode.REGISTCODE){
            //当前为注册接口逻辑使用
            RequestBody body = createBody(map);
            Observable<ResponseUserEntity> ob = HttpFactory.getInstance().factory(HttpType.TOKENSIGNTYPE)
                    .getRetrofit().create(Api.class).requestRegister(body);
           return  ob.map(new ChangeFunction<ResponseUserEntity>());
        }
        return null;
    }
}
