package com.bw.paper.mvp.presenter;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;
import com.bw.paper.mvp.contract.FrameContract;

import javax.inject.Inject;

import io.reactivex.annotations.NonNull;

public class FramePresenter extends BasePresenter<FrameContract.IFrameModel, FrameContract.IFrameView> {

    @Inject
    public FramePresenter(FrameContract.IFrameModel iFrameModel, FrameContract.IFrameView iFrameView) {
        super(iFrameModel, iFrameView);
    }

    public void requestUpdate(){

    }

    @Override
    public void onNext(@NonNull BaseEntity baseEntity) {

    }
}
