package com.bw.paper.mvp.base.view;

import android.os.Bundle;

public interface IFragment {
    int bindLayout();

    void initView();

    void initData();

    void inject();

    //目标activity类型
    void startPage(Bundle bundle, Class clazz);
}
