package com.bw.paper.test.di;

import com.bw.paper.test.TestContract;
import com.bw.paper.test.TestModel;

import dagger.Module;
import dagger.Provides;

@Module
public class Modeles {
    private TestContract.TestViewImpl view;
    public Modeles(TestContract.TestViewImpl view){
        this.view = view;
    }

    @Provides
    public TestContract.TestViewImpl providerView(){
        return view;
    }
    @Provides
    public TestContract.TestModelImpl providerModel(TestModel model){
        return model;
    }
}
