package com.bw.paper.mvp.base.model;

//全部接口解析实体类基类->接口中公共部分
public class BaseEntity {
    public String status;//请求状态
    public String message;//请求消息提示
}
