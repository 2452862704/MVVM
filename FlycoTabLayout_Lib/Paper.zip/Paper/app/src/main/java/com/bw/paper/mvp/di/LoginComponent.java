package com.bw.paper.mvp.di;

import com.bw.paper.mvp.view.user.LoginActivity;
import com.bw.paper.mvp.view.user.RegisterActivity;

import dagger.Component;

@Component(modules = LoginModules.class)
public interface LoginComponent {

    void injectLogin(LoginActivity activity);

    void injectRegister(RegisterActivity activity);

}
