package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;

public class ChannelEntity extends BaseEntity {
    public String values;
}
