package com.bw.paper.mvp.model;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.BaseModel;
import com.bw.paper.mvp.contract.LREContract;
import com.bw.paper.mvp.model.entity.ChannelEntity;
import com.bw.paper.mvp.model.entity.ImageBannerEntity;
import com.bw.paper.mvp.model.entity.NewsEntity;
import com.bw.paper.mvp.model.entity.TextBannerEntity;
import com.bw.paper.network.Api;
import com.bw.paper.network.ChangeFunction;
import com.bw.paper.network.HttpFactory;
import com.bw.paper.network.HttpType;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observable;

/**
 * 针对列表接口界面的请求model
 * */
public class LREModel extends BaseModel implements LREContract.ILREModel {

    @Inject
    public LREModel(){}

    @Override
    public Observable<BaseEntity> requestAll(Map<String, Object>... maps) {
        //根据传递进来的maps 数量创建生成专门用来存放被观察者的集合
        List<Observable<BaseEntity>>observables=new ArrayList<>();
        for (int i =0;i < maps.length;i ++){
            Map<String,Object>map = maps[i];
            observables.add(change2BaseEntity(map));
        }
        return Observable.merge(observables);
    }

    //异步任务转化为BaseEntity任务
    private Observable<BaseEntity> change2BaseEntity(Map<String,Object>map){
        int code = (int) map.get("code");
        map.remove("code");
        Observable<BaseEntity> ob = null;
        switch (code){
            case HttpCode.USERCHANNELCODE:
                //获取首页用户频道接口
                ob =  HttpFactory.getInstance().factory(HttpType.TOKENSIGNTYPE)
                        .getRetrofit().create(Api.class)
                        .requestUserChannels(createBody(map))
                        .map(new ChangeFunction<ChannelEntity>());
                break;
            case HttpCode.CHANNELNEWS:
                //按频道获取新闻列表接口
                ob =  HttpFactory.getInstance().factory(HttpType.TOKENSIGNTYPE)
                        .getRetrofit().create(Api.class)
                        .requestNews(createBody(map))
                        .map(new ChangeFunction<NewsEntity>());
                break;
            case HttpCode.IMAGERBANNERCODE:
                ob = HttpFactory.getInstance().factory(HttpType.TOKEN)
                        .getRetrofit().create(Api.class)
                        .requestImageBanner().map(new ChangeFunction<ImageBannerEntity>());
                 break;
            case HttpCode.TEXTBANNERCODE:
                ob = HttpFactory.getInstance().factory(HttpType.TOKEN)
                        .getRetrofit().create(Api.class)
                        .requestTextBanner().map(new ChangeFunction<TextBannerEntity>());
                break;
        }
        return ob;
    }

    @Override
    public Observable<BaseEntity> request_refresh_load(Map<String, Object> map) {
        return change2BaseEntity(map);
    }
}
