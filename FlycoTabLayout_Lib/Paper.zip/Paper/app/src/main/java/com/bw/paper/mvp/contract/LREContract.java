package com.bw.paper.mvp.contract;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

import java.util.Map;

import io.reactivex.Observable;

public interface LREContract {

    //LREModel
    interface ILREModel extends IModel{

        //列表界面中无论多少接口全部合并请求方法
        Observable<BaseEntity>requestAll(Map<String,Object> ... maps);

        Observable<BaseEntity>request_refresh_load(Map<String,Object>map);

    }

    //LREView
    interface ILREView extends IView{
        //全部数据请求返回方法
        void refreshAll(BaseEntity entity);
        //下拉刷新数据返回
        void refreshRecyckerView(BaseEntity entity);
        //上拉加载数据返回
        void loadMoreRecyclerView(BaseEntity entity);
    }

}
