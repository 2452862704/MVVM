package com.bw.paper.mvp.model;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.BaseModel;
import com.bw.paper.mvp.contract.UserContract;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observable;

public class UserModel extends BaseModel implements UserContract.IUserModel {

    @Inject
    public UserModel(){}

    @Override
    public Observable<BaseEntity> requestUser(Map<String, Object> map) {
        return null;
    }
}
