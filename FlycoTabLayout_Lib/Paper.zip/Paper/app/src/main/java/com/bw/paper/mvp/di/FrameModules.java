package com.bw.paper.mvp.di;

import com.bw.paper.mvp.contract.FrameContract;
import com.bw.paper.mvp.model.FrameModel;

import dagger.Module;
import dagger.Provides;

@Module
public class FrameModules {

    private FrameContract.IFrameView view;

    public FrameModules(FrameContract.IFrameView view){
        this.view = view;
    }

    @Provides
    public FrameContract.IFrameView providerView(){
        return view;
    }

    @Provides
    public FrameContract.IFrameModel providerModel(FrameModel model){
        return model;
    }

}
