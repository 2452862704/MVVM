package com.bw.paper.base;

import com.bw.paper.mvp.base.model.BaseEntity;

public class TestAdapter extends BaseRvAdapter<BaseEntity>{
    public TestAdapter(int layoutId) {
        super(layoutId);
    }

    @Override
    public void convert(BaseRvVH holder, BaseEntity item, int position) {
        holder.setText(0,item.message);
    }
}
