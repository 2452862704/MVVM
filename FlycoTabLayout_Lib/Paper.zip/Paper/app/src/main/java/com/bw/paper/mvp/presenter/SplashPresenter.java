package com.bw.paper.mvp.presenter;

import android.Manifest;
import android.content.pm.PackageManager;

import com.blankj.utilcode.util.PhoneUtils;
import com.bw.paper.App;
import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;
import com.bw.paper.mvp.contract.SplashContract;
import com.bw.paper.mvp.model.entity.ToKenEntity;
import com.bw.paper.utils.LogUtils;
import com.bw.paper.utils.SpUtils;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import androidx.core.app.ActivityCompat;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.schedulers.Schedulers;

public class SplashPresenter extends BasePresenter<SplashContract.ISplashModel, SplashContract.ISplashView> {
    @Inject
    public SplashPresenter(SplashContract.ISplashModel iSplashModel,
                           SplashContract.ISplashView iSplashView) {
        super(iSplashModel, iSplashView);
    }

    //请求服务器token方法
    public void requestToken() {
        Map<String, Object> map = new HashMap<>();
        if (ActivityCompat.checkSelfPermission(App.getInstance().getApplicationContext(),
                Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
//        String imie = PhoneUtils.getIMEI();
        map.put("imie",""+System.currentTimeMillis());
        m.requestToken(map).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this);
    }
    @Override
    public void onNext(@NonNull BaseEntity baseEntity) {
        //请求成功逻辑校验
        ToKenEntity entity = (ToKenEntity) baseEntity;
        LogUtils.show("SplashPresenter->onNext");
        if (entity.status.equals("200")){
            //保存token到本地SP存储中
            SpUtils.saveData("token",entity.getValues().token);
            LogUtils.show("SplashPresenter->onNext1");
            //通知activity界面跳转
            v.refresh();
        }
    }
}
