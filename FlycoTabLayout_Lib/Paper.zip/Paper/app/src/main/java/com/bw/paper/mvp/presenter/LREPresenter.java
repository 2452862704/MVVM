package com.bw.paper.mvp.presenter;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;
import com.bw.paper.mvp.contract.LREContract;
import com.bw.paper.mvp.model.HttpCode;
import com.bw.paper.mvp.model.entity.NewsEntity;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class LREPresenter extends BasePresenter<LREContract.ILREModel, LREContract.ILREView> {

    private int page = 1;
    private LoadMoreOb ob;
    @Inject
    public LREPresenter(LREContract.ILREModel ilreModel, LREContract.ILREView ilreView) {
        super(ilreModel, ilreView);
        ob = new LoadMoreOb(this);
    }

    //请求全部数据方法
    public void requestAll(Map<String,Object>... maps){
        //针对列表接口中的请求参数中的page进行二次拼接操作
        for (int i = 0;i<maps.length;i ++){
            int code = (int) maps[i].get("code");
            switch (code){
                case HttpCode.CHANNELNEWS:
                    maps[i].put("page",page);
                    break;
            }
        }
        m.requestAll(maps).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this);
    }

    public void requestRefresh(Map<String,Object> map){
        page = 1;
        map.put("page",page);
        m.request_refresh_load(map).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this);
    }

    public void requestLoad(Map<String,Object> map){
        page+=1;
        map.put("page",page);
        m.request_refresh_load(map).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(ob);

    }

    @Override
    public void onNext(@NonNull BaseEntity entity) {
         //使用instanceof区分entity类型->列表数据->refreshRecyckerView
         //非列表数据->refreshAll
        if (entity instanceof NewsEntity){
            //新闻列表返回值
            v.refreshRecyckerView(entity);
            return;
        }
        v.refreshAll(entity);

    }

    public void loadMoreNext(BaseEntity entity){
         v.loadMoreRecyclerView(entity);
    }

    public static class LoadMoreOb implements Observer<BaseEntity>{

        private LREPresenter lrePresenter;

        public LoadMoreOb(LREPresenter lrePresenter){
            this.lrePresenter = lrePresenter;
        }

        @Override
        public void onSubscribe(@NonNull Disposable d) {
            lrePresenter.onSubscribe(d);
        }

        @Override
        public void onNext(@NonNull BaseEntity entity) {
            lrePresenter.loadMoreNext(entity);
        }

        @Override
        public void onError(@NonNull Throwable e) {
             lrePresenter.onError(e);
        }

        @Override
        public void onComplete() {
             lrePresenter.onComplete();
        }
    }

}
