package com.bw.paper.mvp.contract;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

import java.util.Map;

import io.reactivex.Observable;

/**
 * 启屏页契约接口
 * */
public interface SplashContract {

    //启屏页Model
    interface ISplashModel extends IModel{
        //生成请求token接口的被观察者
        Observable<BaseEntity>requestToken(Map<String,Object> map);
    }

    //启屏页View
    interface ISplashView extends IView{
        //请求完成后->回掉通知activity进行界面跳转
        void refresh();
    }

}
