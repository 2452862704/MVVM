package com.bw.paper.utils;

import android.widget.Toast;

import com.bw.paper.App;

public class ToastUtils {

    public static void showMsg(String msg){
        Toast.makeText(App.getInstance().getApplicationContext(),msg,Toast.LENGTH_SHORT).show();
    }

}
