package com.bw.paper.base;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public abstract class BaseRvAdapter<T> extends RecyclerView.Adapter<BaseRvVH> {

    private int layoutId;
    private List<T>datas=new ArrayList<>();

    public BaseRvAdapter(int layoutId){
        this.layoutId = layoutId;
    }

    public void setNewData(List<T>list){
        datas.clear();
        datas.addAll(list);
        notifyDataSetChanged();
    }

    public abstract void convert(BaseRvVH holder,T item,int position);

    @NonNull
    @Override
    public BaseRvVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(layoutId,parent,false);
        return new BaseRvVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BaseRvVH holder, int position) {
        convert(holder,datas.get(position),position);
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }
}
