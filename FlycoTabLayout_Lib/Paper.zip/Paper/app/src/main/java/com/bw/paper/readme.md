1.人民日报客户端:
  网络请求->http->POST->requestbody
  网络安全->token,sign
  x5浏览器使用，js交互
  gsy播放器使用
  四大组件;
  umeng全家桶集成以及使用;
  协调者布局;
  语音识别SDK接入;
  smartrefreshlayout->自定义头布局
  沉浸式状态栏使用;
  flycotablayout使用;
  Glide图片加载框架封装;
  自定义viewUI效果实现;
  git代码仓库版本管理;
作业检查:
  业务逻辑实现结果；
  UI是否一比一还原;
  全部dp单位设置到dimens中->dimens百分比适配
  color写到colos下，string写到strings
  命名严禁出现f1,f2,中文拼音，中英文混合,i,j,k,l,o,  
  抽查代码实现过程，以及实现思路
  严禁重写项目
  
  
  