package com.bw.paper.mvp.view.news;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.view.BaseFragment;
import com.bw.paper.mvp.contract.LREContract;
import com.bw.paper.mvp.presenter.LREPresenter;

public class NewsFragment extends BaseFragment<LREPresenter> implements LREContract.ILREView {
    @Override
    public int bindLayout() {
        return 0;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }

    @Override
    public void inject() {

    }

    @Override
    public void refreshAll(BaseEntity entity) {

    }

    @Override
    public void refreshRecyckerView(BaseEntity entity) {

    }

    @Override
    public void loadMoreRecyclerView(BaseEntity entity) {

    }
}
