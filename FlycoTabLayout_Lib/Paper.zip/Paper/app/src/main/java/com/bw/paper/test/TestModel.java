package com.bw.paper.test;

import com.bw.paper.mvp.base.model.BaseModel;

import javax.inject.Inject;

public class TestModel extends BaseModel implements TestContract.TestModelImpl {

    @Inject
    public TestModel(){}

    @Override
    public void request() {

    }
}
