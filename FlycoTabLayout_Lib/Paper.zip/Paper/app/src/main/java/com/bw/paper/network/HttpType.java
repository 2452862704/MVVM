package com.bw.paper.network;

public enum HttpType {
    UPLOADTYPE,SIGNTYPE,TOKENSIGNTYPE,TOKEN
}
