package com.bw.paper.base;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BaseRvVH extends RecyclerView.ViewHolder {

    //设置文字内容
    public BaseRvVH setText(int id,String content){
        TextView tv = rootView.findViewById(id);
        tv.setText(content);
        return this;
    }
    //获取itemview关联控件
    public <V extends View> V findView(int id){
        return rootView.findViewById(id);
    }

    private View rootView;//关联的itemview视图对象

    public BaseRvVH(@NonNull View itemView) {
        super(itemView);
        rootView = itemView;
    }
}
