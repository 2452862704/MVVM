package com.bw.paper.mvp.base.model;

import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.RequestBody;

public abstract class BaseModel implements IModel{
    @Override
    public RequestBody createBody(Map<String, Object> map) {
        if (map == null)
            return null;
        return RequestBody.create(MediaType.parse("application/json"),new Gson().toJson(map));
    }
}
