package com.bw.paper.mvp.di;

import com.bw.paper.mvp.view.news.ContentNewsFragment;
import com.bw.paper.mvp.view.news.NewsFragment;
import dagger.Component;

@Component(modules = LREModules.class)
public interface LREComponent {

    void injectNewsFragment(NewsFragment fragment);

    void injectContentNewsFragment(ContentNewsFragment fragment);

}
