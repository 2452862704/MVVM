package com.bw.paper.mvp.base.view;

import android.os.Bundle;

//view层界面处理方法
public interface IActivity {

    int bindLayout();

    void initView();

    void initData();

    void inject();

    //目标activity类型
    void startPage(Bundle bundle,Class clazz);

}
