package com.bw.paper.mvp.view.user;

public class SetUserActivity {
}
