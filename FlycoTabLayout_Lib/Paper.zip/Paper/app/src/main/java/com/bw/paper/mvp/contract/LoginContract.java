package com.bw.paper.mvp.contract;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

import java.util.Map;

import io.reactivex.Observable;

public interface LoginContract {

    interface ILoginModel extends IModel{
        Observable<BaseEntity>request(Map<String,Object>map);
    }

    interface ILoginView extends IView{
        void refreshView(BaseEntity entity);
    }

}
