package com.bw.paper.mvp.di;

import com.bw.paper.mvp.view.user.UserFragment;

import dagger.Component;

@Component(modules = UserModules.class)
public interface UserComponent {

    void inject(UserFragment fragment);

}
