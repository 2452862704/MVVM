package com.bw.paper.mvp.model;

public class HttpCode {
    public final static int LOGINCODE = 1;
    public final static int REGISTCODE = 2;
    public final static int UPDATEUSERCODE = 3;
    public final static int UPLOADIMGCODE = 4;
    public final static int SELUSERCODE = 5;
    public final static int USERCHANNELCODE = 6;
    public final static int CHANNELNEWS = 7;
    public final static int TEXTBANNERCODE = 8;
    public final static int IMAGERBANNERCODE = 9;
}
