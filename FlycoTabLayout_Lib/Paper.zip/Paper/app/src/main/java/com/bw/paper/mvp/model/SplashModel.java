package com.bw.paper.mvp.model;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.BaseModel;
import com.bw.paper.mvp.contract.SplashContract;
import com.bw.paper.mvp.model.entity.ToKenEntity;
import com.bw.paper.network.Api;
import com.bw.paper.network.ChangeFunction;
import com.bw.paper.network.HttpFactory;
import com.bw.paper.network.HttpType;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observable;

public class SplashModel extends BaseModel implements SplashContract.ISplashModel {

    @Inject
    public SplashModel(){}

    @Override
    public Observable<BaseEntity> requestToken(Map<String, Object> map) {
        Observable<ToKenEntity>ob = HttpFactory.getInstance()
                .factory(HttpType.SIGNTYPE)
                .getRetrofit().create(Api.class)
                .requestToken(createBody(map));
        return ob.map(new ChangeFunction<ToKenEntity>());
    }
}
