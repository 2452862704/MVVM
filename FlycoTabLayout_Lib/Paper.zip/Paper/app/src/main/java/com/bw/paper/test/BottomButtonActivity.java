package com.bw.paper.test;

import android.graphics.Color;
import android.os.Bundle;

import com.bw.paper.R;
import com.bw.paper.widget.BottomButton;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class BottomButtonActivity extends AppCompatActivity implements BottomButton.SelectListener {

    private BottomButton bottom1,bottom2;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_button);
        bottom1 = findViewById(R.id.bottom1);
        bottom2 = findViewById(R.id.bottom2);
        bottom1.setContent("bottom1").setNomalColor(Color.BLACK)
                .setSelColor(Color.RED)
                .setNomalImg(R.drawable.js_img_add)
                .setSelImg(R.drawable.js_img_asc_arrow)
                .setListener(this::onSelect)
                .setShowPoint(false);
        bottom2.setContent("2222222").setNomalColor(Color.BLACK)
                .setSelColor(Color.RED)
                .setNomalImg(R.drawable.js_img_assets_income)
                .setSelImg(R.drawable.js_img_back)
                .setListener(this::onSelect)
                .setShowPoint(false);
    }

    @Override
    public void onSelect(int id) {
        if (id == R.id.bottom1){
            bottom2.clearSelect();
        }else {
            bottom1.clearSelect();
        }
    }
}
