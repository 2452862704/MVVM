package com.bw.paper.mvp.di;

import com.bw.paper.mvp.view.SplashActivity;
import dagger.Component;

@Component(modules = SplashModules.class)
public interface SplashComponent {
    void injectSplash(SplashActivity activity);
}
