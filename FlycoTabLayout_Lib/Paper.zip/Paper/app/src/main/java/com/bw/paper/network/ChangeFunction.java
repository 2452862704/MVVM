package com.bw.paper.network;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.presenter.LREPresenter;

import io.reactivex.annotations.NonNull;
import io.reactivex.functions.Function;

public class ChangeFunction<T extends  BaseEntity> implements Function <T ,BaseEntity>{
    @Override
    public BaseEntity apply(@NonNull T t) throws Exception {
        return t;
    }
}
