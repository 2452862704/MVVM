package com.bw.paper.mvp.model;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.BaseModel;
import com.bw.paper.mvp.contract.FrameContract;

import java.util.Map;

import javax.inject.Inject;

import io.reactivex.Observable;

public class FrameModel extends BaseModel implements FrameContract.IFrameModel {

    @Inject
    public FrameModel(){}

    @Override
    public Observable<BaseEntity> request(Map<String, Object> map) {
        return null;
    }
}
