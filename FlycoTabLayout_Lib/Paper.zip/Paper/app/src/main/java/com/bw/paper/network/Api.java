package com.bw.paper.network;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.model.entity.ChannelEntity;
import com.bw.paper.mvp.model.entity.ImageBannerEntity;
import com.bw.paper.mvp.model.entity.NewsEntity;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.mvp.model.entity.TextBannerEntity;
import com.bw.paper.mvp.model.entity.ToKenEntity;

import java.util.List;

import io.reactivex.Observable;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface Api {

    //    String BaseUrl = "http://118.195.161.134:8088/";//生产环境地址
    String BaseUrl = "http://118.195.161.134:8066/";//测试环境地址
    String FileUrl = "http://118.195.161.134:8066/fileDownload?fileName=";

    @POST("sysToken/getToken")
    Observable<ToKenEntity> requestToken(@Body RequestBody body);
    @POST("sysUser/loginUser")
    Observable<ResponseUserEntity>requestLogin(@Body RequestBody body);
    @POST("sysUser/registerUser")
    Observable<ResponseUserEntity>requestRegister(@Body RequestBody body);
    @POST("sysUser/userValues")
    Observable<ResponseUserEntity>requestUser(@Body RequestBody body);
    @POST("sysUser/updateUser")
    Observable<ResponseUserEntity>requestUpdateUser(@Body RequestBody body);
    @POST("sysNews/channelNews")
    Observable<NewsEntity>requestNews(@Body RequestBody body);
    @POST("sysChannel/userChannel")
    Observable<ChannelEntity>requestUserChannels(@Body RequestBody body);
    @POST("sysBanner/textBannerNews")
    Observable<TextBannerEntity>requestTextBanner();
    @POST("sysBanner/bannerNews")
    Observable<ImageBannerEntity>requestImageBanner();
    @Multipart
    @POST("fileUpload")
    Observable<BaseEntity>requestUploadHead(@Part List<MultipartBody.Part>parts);
//    @POST("sysToken/testToken")
//    Observable<ResultEntity> requestTest();

}
