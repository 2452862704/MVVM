package com.bw.paper.mvp.contract;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;
import com.bw.paper.mvp.model.entity.UserItemEntity;
import com.bw.paper.mvp.model.entity.UserMenuEntity;

import java.util.List;
import java.util.Map;

import io.reactivex.Observable;

public interface UserContract {

    interface IUserModel extends IModel{
        Observable<BaseEntity>requestUser(Map<String,Object>map);
    }

    interface IUserView extends IView{
        //用户信息回调方法,今日签到任务列表
        void refresh(BaseEntity entity);
        //用户菜单界面
        void refreshMenu(List<UserMenuEntity>menues);
        //积分商城等item
        void refreshItemes(List<UserItemEntity>itemes);
    }

}
