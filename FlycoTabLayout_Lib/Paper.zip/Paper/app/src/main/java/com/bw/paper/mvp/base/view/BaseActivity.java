package com.bw.paper.mvp.base.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import com.blankj.utilcode.util.BarUtils;
import com.bw.paper.R;
import com.bw.paper.mvp.base.presenter.IPresenter;
import com.bw.paper.utils.LogUtils;
import com.bw.paper.utils.ToastUtils;
import com.bw.paper.widget.LoadDialog;
import com.umeng.analytics.MobclickAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import javax.inject.Inject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity <P extends IPresenter>extends AppCompatActivity implements IView,IActivity {

    @Inject
    public P p;
    protected LoadDialog loadDialog;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(bindLayout());
        loadDialog = new LoadDialog(this);
        //修改状态栏当中的图片以及文字颜色
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            //把状态栏标记为浅色，然后状态栏的字体颜色自动转换为深色
        }
        BarUtils.setStatusBarColor(this, Color.WHITE);
        //添加让出状态栏高度->防止contentView布局绘制到状态栏上
        BarUtils.addMarginTopEqualStatusBarHeight(addStatusView());
        initView();
        inject();
        getLifecycle().addObserver(p);
        initData();
    }

    public void setStatuesColor(int color){
        if (color == getResources().getColor(R.color.white)) {
            LogUtils.show("white");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                //把状态栏标记为浅色，然后状态栏的字体颜色自动转换为深色
            }
        }
        else {
            LogUtils.show("red");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_VISIBLE);
                //把状态栏标记为浅色，然后状态栏的字体颜色自动转换为深色
            }
        }
        BarUtils.setStatusBarColor(this, color);
        BarUtils.addMarginTopEqualStatusBarHeight(addStatusView());
    }

    public abstract View addStatusView();

    @Override
    protected void onResume() {
        super.onResume();
        MobclickAgent.onResume(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        MobclickAgent.onPause(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getLifecycle().removeObserver(p);
    }

    @Override
    public void showDialog() {
        LogUtils.show("showDialog()");
        loadDialog.show();
    }

    @Override
    public void hideDialog() {
        LogUtils.show("hideDialog()");
        loadDialog.dismiss();
    }

    @Override
    public void showMsg(String msg) {
        ToastUtils.showMsg(msg);
    }

    @Override
    public void startPage(Bundle bundle,Class clazz) {
        Intent intent = new Intent(this,clazz);
        if (bundle!=null)
            intent.putExtras(bundle);
        startActivity(intent);
    }

    public void startPage(Class clazz){
        startPage(null,clazz);
    }

    protected <T extends View> T f(int id){
        return findViewById(id);
    }
}
