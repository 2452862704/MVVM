package com.bw.paper.network;

import com.bw.paper.network.interceptor.ResponsInterceptor;
import com.bw.paper.network.interceptor.SignInterceptor;
import com.bw.paper.network.interceptor.TokenInterceptor;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public final class TokenSignRetrofit implements HttpImpl {

    private TokenSignRetrofit(){}
    private static Retrofit retrofit;

    @Override
    public Retrofit getRetrofit() {
        return retrofit;
    }

    public static class Build{

        public Build(){
            create();
        }

        private void create(){
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient.Builder okBuild = new OkHttpClient.Builder();
            okBuild.addInterceptor(new TokenInterceptor());
            okBuild.addInterceptor(new SignInterceptor());
            okBuild.addInterceptor(new ResponsInterceptor());
            okBuild.addInterceptor(interceptor);
            okBuild.connectTimeout(30*1000, TimeUnit.MILLISECONDS);
            okBuild.readTimeout(30*1000,TimeUnit.MILLISECONDS);
            okBuild.writeTimeout(30*1000,TimeUnit.MILLISECONDS);
            Retrofit.Builder builder = new Retrofit.Builder();
            builder.baseUrl(Api.BaseUrl);
            builder.client(okBuild.build());
            builder.addCallAdapterFactory(RxJava2CallAdapterFactory.create());
            builder.addConverterFactory(GsonConverterFactory.create());
            retrofit = builder.build();
        }

        public TokenSignRetrofit build(){
            return new TokenSignRetrofit();
        }
    }


}
