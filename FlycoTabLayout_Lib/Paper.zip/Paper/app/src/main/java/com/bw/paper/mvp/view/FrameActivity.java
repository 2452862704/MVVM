package com.bw.paper.mvp.view;

import android.graphics.Color;
import android.view.View;
import com.bw.paper.R;
import com.bw.paper.mvp.base.view.BaseActivity;
import com.bw.paper.mvp.contract.FrameContract;
import com.bw.paper.mvp.di.DaggerFrameComponent;
import com.bw.paper.mvp.di.FrameModules;
import com.bw.paper.mvp.presenter.FramePresenter;
import com.bw.paper.mvp.view.user.UserFragment;
import com.bw.paper.utils.LogUtils;
import com.bw.paper.widget.BottomButton;

import java.util.Map;

import androidx.fragment.app.FragmentTransaction;

public class FrameActivity extends BaseActivity<FramePresenter> implements
        FrameContract.IFrameView, BottomButton.SelectListener {

    private UserFragment userFragment;
    private BottomButton frame_news_btn,frame_pepole_btn,frame_video_btn,
            frame_live_btn,frame_user_btn;

    @Override
    public View addStatusView() {
        return f(R.id.frame_linear);
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_main;
    }

    @Override
    public void initView() {
        frame_news_btn = f(R.id.frame_news_btn);
        frame_pepole_btn = f(R.id.frame_pepole_btn);
        frame_video_btn = f(R.id.frame_video_btn);
        frame_live_btn = f(R.id.frame_live_btn);
        frame_user_btn = f(R.id.frame_user_btn);
        frame_news_btn.setSelColor(Color.RED)
                .setNomalColor(Color.GRAY)
                .setShowPoint(false)
                .setNomalImg(R.drawable.res_7icon_216)
                .setSelImg(R.drawable.res_7icon_211)
                .setContent("新闻");
        frame_pepole_btn.setSelColor(Color.RED)
                .setNomalColor(Color.GRAY)
                .setShowPoint(false)
                .setNomalImg(R.drawable.res_7icon_217)
                .setSelImg(R.drawable.res_7icon_212)
                .setContent("人民号");
        frame_video_btn.setSelColor(Color.RED)
                .setNomalColor(Color.GRAY)
                .setShowPoint(false)
                .setNomalImg(R.drawable.res_7icon_218)
                .setSelImg(R.drawable.res_7icon_213)
                .setContent("视频");
        frame_live_btn.setSelColor(Color.RED)
                .setNomalColor(Color.GRAY)
                .setShowPoint(false)
                .setNomalImg(R.drawable.res_7icon_219)
                .setSelImg(R.drawable.res_7icon_214)
                .setContent("直播");
        frame_user_btn.setSelColor(Color.RED)
                .setNomalColor(Color.GRAY)
                .setShowPoint(false)
                .setNomalImg(R.drawable.res_7icon)
                .setSelImg(R.drawable.res_7icon_215)
                .setContent("我的");
        frame_news_btn.setListener(this::onSelect);
        frame_pepole_btn.setListener(this::onSelect);
        frame_video_btn.setListener(this::onSelect);
        frame_live_btn.setListener(this::onSelect);
        frame_user_btn.setListener(this::onSelect);
        showFragment(R.id.frame_user_btn);
        frame_user_btn.selectCheck();
    }

    @Override
    public void initData() {

    }

    @Override
    public void inject() {
        DaggerFrameComponent.builder().frameModules(
                new FrameModules(this)).build().inject(this);
    }

    @Override
    public void refresh(Map<String, Object> resultMap) {

    }

    @Override
    public void onSelect(int id) {
        hideFragment();
        showFragment(id);
    }

    private void hideFragment(){
        setStatuesColor(getResources().getColor(R.color.white));
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        if (userFragment!=null)
            ft.hide(userFragment);
        ft.commit();
    }

    private void showFragment(int id){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        switch (id){
            case R.id.frame_news_btn:
                frame_pepole_btn.clearSelect();
                frame_video_btn.clearSelect();
                frame_live_btn.clearSelect();
                frame_user_btn.clearSelect();
                break;
            case R.id.frame_pepole_btn:
                frame_news_btn.clearSelect();
                frame_video_btn.clearSelect();
                frame_live_btn.clearSelect();
                frame_user_btn.clearSelect();
                break;
            case R.id.frame_video_btn:
                frame_news_btn.clearSelect();
                frame_pepole_btn.clearSelect();
                frame_live_btn.clearSelect();
                frame_user_btn.clearSelect();
                break;
            case R.id.frame_live_btn:
                frame_news_btn.clearSelect();
                frame_pepole_btn.clearSelect();
                frame_video_btn.clearSelect();
                frame_user_btn.clearSelect();
                break;
            case R.id.frame_user_btn:
                setStatuesColor(getResources().getColor(R.color.red));
                frame_news_btn.clearSelect();
                frame_pepole_btn.clearSelect();
                frame_video_btn.clearSelect();
                frame_live_btn.clearSelect();
                if (userFragment==null){
                    userFragment = new UserFragment();
                    ft.add(R.id.fragment_linear,userFragment);
                }else
                    ft.show(userFragment);
                break;

        }
        ft.commit();
    }
}
