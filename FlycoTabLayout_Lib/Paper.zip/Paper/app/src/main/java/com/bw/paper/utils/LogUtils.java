package com.bw.paper.utils;

import android.util.Log;

public class LogUtils {
    public static boolean DEBUG = true;
    public static void show(String msg){
        if (DEBUG)
            Log.e("ZXY",msg);
    }
}
