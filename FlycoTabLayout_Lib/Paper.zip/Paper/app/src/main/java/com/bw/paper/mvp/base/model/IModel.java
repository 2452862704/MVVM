package com.bw.paper.mvp.base.model;

import java.util.HashMap;
import java.util.Map;

import okhttp3.RequestBody;

//model 层接口
public interface IModel {

    //请求参数转化为requestbody
    RequestBody createBody(Map<String,Object> map);
}
