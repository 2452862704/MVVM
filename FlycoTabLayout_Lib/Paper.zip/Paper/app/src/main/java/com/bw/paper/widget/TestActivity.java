package com.bw.paper.widget;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.bw.paper.R;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.network.Api;
import com.bw.paper.network.HttpFactory;
import com.bw.paper.network.HttpType;
import com.bw.paper.utils.LogUtils;
import com.bw.paper.utils.ToastUtils;
import com.google.gson.Gson;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import io.reactivex.Observer;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.MediaType;
import okhttp3.RequestBody;

public class TestActivity extends AppCompatActivity implements View.OnClickListener {

    private Button photo_btn,camera_btn,update_user_btn;
    private ImageView img;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        photo_btn = findViewById(R.id.photo_btn);
        camera_btn = findViewById(R.id.camera_btn);
        update_user_btn = findViewById(R.id.update_user_btn);
        img = findViewById(R.id.img);
        photo_btn.setOnClickListener(this::onClick);
        camera_btn.setOnClickListener(this::onClick);
        update_user_btn.setOnClickListener(this::onClick);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        Intent intent = new Intent(this,PhotoActivity.class);
        if (R.id.photo_btn == id){
//            openPhoto();
            intent.putExtra("type",0);
            startActivity(intent);
        }else if (R.id.camera_btn == id){
//            openCamera();
            intent.putExtra("type",1);
            startActivity(intent);
        }else if (R.id.update_user_btn == id){
            /**
             * {
             *   "null": true,
             *   "sign": "string",
             *   "user_id": 0,
             *   "user_img": "string",
             *   "user_integral": 0,
             *   "user_name": "string",
             *   "user_phone": 0,
             *   "user_pwd": "string",
             *   "user_sex": "string"
             * }
             * */
            Map<String,Object>map = new HashMap<>();
            map.put("user_id",1);
            map.put("user_img","screenshot_20210523_215303.png");
            map.put("user_integral",1);
            map.put("user_name","guoyangwen");
            map.put("user_phone",123456789);
            map.put("user_pwd","abcdefg");
            map.put("user_sex","1");
            RequestBody body = RequestBody.create(MediaType.parse("application/json"),new Gson().toJson(map));
            HttpFactory.getInstance().factory(HttpType.TOKENSIGNTYPE)
                    .getRetrofit().create(Api.class).requestUpdateUser(body)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<ResponseUserEntity>() {
                        @Override
                        public void onSubscribe(@NonNull Disposable d) {

                        }

                        @Override
                        public void onNext(@NonNull ResponseUserEntity responseUserEntity) {
                            LogUtils.show("onNext:"+responseUserEntity.status+"&&"+responseUserEntity.message);
                        }

                        @Override
                        public void onError(@NonNull Throwable e) {
                            LogUtils.show("onError:"+e.toString());
                        }

                        @Override
                        public void onComplete() {

                        }
                    });

        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK){
            ToastUtils.showMsg("获取图片失败");
            return;
        }
        String path = data.getStringExtra("path");
        LogUtils.show("path:"+path);
    }
}
