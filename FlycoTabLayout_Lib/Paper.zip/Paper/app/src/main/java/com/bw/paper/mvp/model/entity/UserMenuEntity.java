package com.bw.paper.mvp.model.entity;

public class UserMenuEntity {

    //图标本地资源ID
    public int imgId;
    //名称
    public String name;
    //目标activity Class
    public Class clazz;

    public UserMenuEntity(int imgId,String name,Class clazz){
        this.imgId = imgId;
        this.name = name;
        this.clazz = clazz;
    }

}
