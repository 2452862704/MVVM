package com.bw.paper.widget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import com.blankj.utilcode.util.ConvertUtils;
import com.bw.paper.R;
import com.bw.paper.utils.LogUtils;

import androidx.annotation.Nullable;

public class TimeLineView extends View {

    private Bitmap selBit;//已完成签到任务图片res_7icon_362
    private Bitmap popBit;//翻倍气泡背景图module_integral_double_bg
    private int selColor;//已完成任务颜色
    private int nomalColor;//默认任务颜色
    private String[] names = {"1连签","2连签","3连签","4连签","5连签","6连签","7连签"};
    private String[] numes = {"5","10","10","20","25","25","50"};
    private int width = 0;//控件的宽度
    private int height = 0;//控件的高度
    private int itemWidth = 0;//每个圈或者线的宽度
    private int popHeight = 0;//弹窗高度
    private int tvHeight = ConvertUtils.dp2px(20);//签到文字高度
    private int selIndex = 0;//用户当前签到进度

    private Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public TimeLineView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        width = getMeasuredWidth();
        height = getMeasuredHeight();
        itemWidth = width/13;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawSign(canvas);
    }

    private void drawSign(Canvas canvas){

        for(int i = 0;i < 13;i ++){
            if (i % 2 == 0){
                //偶数画圈
                paint.setColor(nomalColor);
                if (i<=selIndex*2){
                    paint.setColor(selColor);
                }
                if (i == 6 || i == 12)
                    paint.setColor(selColor);
                canvas.drawCircle(itemWidth*i+itemWidth/2,
                        popHeight+(height-popHeight-tvHeight)/2,itemWidth/2,paint);
                paint.setColor(Color.WHITE);
                canvas.drawCircle(itemWidth*i+itemWidth/2,
                        popHeight+(height-popHeight-tvHeight)/2,
                        itemWidth/2-ConvertUtils.dp2px(1),paint);
                //绘制圆圈中间的签到积分
                paint.setColor(nomalColor);
                if (i == 6 || i == 12) {
                    paint.setColor(selColor);
                }
                paint.setTextSize(itemWidth/2);
                paint.setFakeBoldText(true);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText(numes[i/2],itemWidth*i+itemWidth/2,
                        popHeight+(height-popHeight-tvHeight)/2+(itemWidth/4),paint);
                paint.setColor(nomalColor);
                //绘制气泡弹窗
                if (i == 6 || i == 12){
//                    Rect dct = new Rect();
//                    dct.left = itemWidth*i+popBit.getWidth()/4;
//                    dct.right = itemWidth*i+popBit.getWidth()/2;
//                    dct.top = 0;
//                    dct.bottom = popHeight-popHeight/2;
//                    canvas.drawBitmap(popBit,itemWidth*i,0,paint);
                    canvas.drawBitmap(popBit,itemWidth*i,0,paint);
//                    canvas.drawBitmap(popBit,null,dct,paint);
                    paint.setTextSize(itemWidth/4);
                    paint.setColor(Color.WHITE);
                    canvas.drawText("翻倍",itemWidth*i+itemWidth/2,popHeight/2+ConvertUtils.dp2px(1),paint);
                    //设置连签文字颜色
                    paint.setColor(selColor);
                }
                paint.setTextSize(itemWidth/3);
                canvas.drawText(names[i/2],itemWidth*i+itemWidth/2,height-ConvertUtils.dp2px(2),paint);
                //绘制用户已签到图片
                if (i<=selIndex*2){
                    LogUtils.show("绘制用户已签到图片"+selBit.getWidth()+selBit.getHeight());
                    //使用rect限制图片绘制区域,保证图片绘制在view上时在对应的圈以内
                    Rect dct = new Rect();
                    dct.left = itemWidth*i+ConvertUtils.dp2px(1);
                    dct.right = itemWidth*(i+1)-ConvertUtils.dp2px(1);
                    dct.top = popHeight+(height-popHeight-tvHeight)/2-itemWidth/2
                            +ConvertUtils.dp2px(1);
                    dct.bottom = popHeight+(height-popHeight-tvHeight)/2+itemWidth/2
                            -ConvertUtils.dp2px(1);
                    LogUtils.show("绘制用户已签到图片"+dct.toString());
                    canvas.drawBitmap(selBit,null,dct,null);
                }
            }else {
                //基数画线
                paint.setColor(nomalColor);
                canvas.drawLine(itemWidth*i,popHeight+(height-popHeight-tvHeight)/2
                                -ConvertUtils.dp2px(1)/2,itemWidth*(i+1),
                        popHeight+(height-popHeight-tvHeight)/2+
                                ConvertUtils.dp2px(1)/2,paint);
            }
        }

    }

    private void init(){
        selBit = BitmapFactory.decodeResource(getResources(), R.drawable.res_7icon_362);
        popBit = BitmapFactory.decodeResource(getResources(),R.drawable.module_integral_double_bg);
        selColor = Color.RED;
        nomalColor = Color.GRAY;
        popHeight = popBit.getHeight()+ConvertUtils.dp2px(5);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (selBit!=null)
            selBit.recycle();
        if (popBit!=null)
            popBit.recycle();
    }
}
