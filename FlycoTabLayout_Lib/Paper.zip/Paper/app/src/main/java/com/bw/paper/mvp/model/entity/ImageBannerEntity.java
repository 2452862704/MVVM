package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;

public class ImageBannerEntity extends BaseEntity {
    public String values;
}
