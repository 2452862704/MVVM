package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.google.gson.Gson;

public class ToKenEntity extends BaseEntity {
    public String values;

    public Values getValues() {
        Values v = new Gson().fromJson(values,Values.class);
        return v;
    }

    public static class Values{
         public String token;
    }

}
