package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;

/**
 * 首页新闻列表数据
 * */
public class NewsEntity extends BaseEntity {
    public String values;
}
