package com.bw.paper.network;


import com.bw.paper.network.interceptor.SignInterceptor;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public final class SignRetrofit implements HttpImpl{

    private SignRetrofit(){}
    private static Retrofit retrofit;

    @Override
    public Retrofit getRetrofit() {
        return retrofit;
    }

    public static class Build{

        public Build(){
            createRetrofit();
        }

        private void createRetrofit(){
            OkHttpClient.Builder okBuilder = new OkHttpClient.Builder();
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            okBuilder.addInterceptor(new SignInterceptor());
            okBuilder.addInterceptor(interceptor);
            okBuilder.connectTimeout(30*1000, TimeUnit.MILLISECONDS);
            okBuilder.writeTimeout(30*1000,TimeUnit.MILLISECONDS);
            okBuilder.readTimeout(30*1000,TimeUnit.MILLISECONDS);
            Retrofit.Builder builder = new Retrofit.Builder();
            builder.client(okBuilder.build());
            builder.baseUrl(Api.BaseUrl);
            builder.addCallAdapterFactory(RxJava2CallAdapterFactory.create());
            builder.addConverterFactory(GsonConverterFactory.create());
            retrofit = builder.build();
        }

        public SignRetrofit build(){
            return new SignRetrofit();
        }
    }
}
