网络请求框架整合:RX全家桶框架整合;
为什么使用rx全家桶:OKHttp框架发起网络请求->同步请求->当前线程发起，
异步请求->请求回掉结果在子线程->线程调度;
异步任务处理->RXjava,RXAndroid->调度线程->
异步任务操作符->merge合并多个异步请求任务,flatmap异步任务转化操作符
人民日报客户端接口使用规则:获取token接口，
剩下客户端使用的接口都包含token令牌->
服务器读取请求头中token字段比较字符串是否为服务器下发的token
，是允许接入到服务器，否拒绝请求，sign签名防止本次请求被篡改
使用gettoken接口获取服务器下发token保存到本地SP中->每次接口请求时直接提取使用,拼接到请求头中
sign->全部接口请求值拼接为一个新的字符串->新拼接出来的字符串做升序排序->升序排序后的新字符串
升序排序后的新字符串+tamboo->MD5加密->Android手机端md5加密默认返回的值大写
大写转小写
token拦截器:给每一个请求接口的请求头中添加token->
配置完成token拦截器后不需要用retrofit@Heads()注解手动配置
sign拦截器:给每个请求接口的请求体的json对象中添加sign字段，
value值为当前接口请求参数的字符串的md5加密后的值
response拦截器:针对错误的请求服务器返回responsecode为500等其他错误状态码->
onerro->response拦截器修改错误的responsecode值使其进入onnext回掉方法处理
建造者->根据不同业务需求(接口请求规则,接口Atoken,sign,接口Bsign，
接口C上传文件到服务器->隐藏掉网络请求工具类配置过程,
给使用者提供一个配置完成的retrofit对象),
工厂(接口请求规则,接口Atoken,sign,接口Bsign，
接口C上传文件到服务器,生产不同产品),单例入口值产生一次对象
Day01:
Gradle依赖管理->统一gradle依赖版本
创建config.gradle文件->全部三方依赖全部配置到config.gradle中
->无论当前项目中有多少个module统一使用config.gradle文件下的依赖
->所有module下的依赖版本统一
multidex->使用->1个apk文件下默认打包时产生dex文件->java编译后的代码->
1个.dex文件最多有65535个方法->可以写编写代码在构建项目或者运行项目时
报错提示当前项目的方法数大于65535个
产生多个dex文件大于65535部分的方法放入到另外的dex文件中
walle美团三方多渠道打包框架集成
Android SDK版本9.0后要求http协议请求为https
res->xml配置允许http协议请求
mvp架构封装->




