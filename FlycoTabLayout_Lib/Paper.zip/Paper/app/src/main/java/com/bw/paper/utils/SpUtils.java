package com.bw.paper.utils;

import android.content.SharedPreferences;

import com.bw.paper.App;

public class SpUtils {
    private static String name = "netcatch";

    public static void saveData(String key,String value){
        SharedPreferences sp = App.getInstance().getApplicationContext().getSharedPreferences(name,0);
        sp.edit().putString(key,value).commit();
    }

    public static String readData(String key){
        SharedPreferences sp = App.getInstance().getApplicationContext().getSharedPreferences(name,0);
        return sp.getString(key,"");
    }


}
