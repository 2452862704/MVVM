package com.bw.paper.mvp.presenter;

import com.bw.paper.App;
import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;
import com.bw.paper.mvp.contract.LoginContract;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.mvp.model.entity.UserEntity;
import com.bw.paper.utils.ToastUtils;

import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.annotations.NonNull;
import io.reactivex.schedulers.Schedulers;

public class LoginPresenter extends BasePresenter<LoginContract.ILoginModel, LoginContract.ILoginView> {

    @Inject
    public LoginPresenter(LoginContract.ILoginModel iLoginModel, LoginContract.ILoginView iLoginView) {
        super(iLoginModel, iLoginView);
    }

    //声明对应请求方法
    //phone->当前用户登录的手机号
    //pwd->用户密码
    public void requestLogin(long phone,String pwd,int code){
        if (pwd.isEmpty()){
            ToastUtils.showMsg("当前密码为空");
            return;
        }
        Map<String,Object>map = new HashMap<>();
        map.put("phone",phone);
        map.put("pwd",pwd);
        map.put("code",code);
        m.request(map).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(this);
    }

    @Override
    public void onNext(@NonNull BaseEntity entity) {
        //接收到服务器返回值->用户数据保存到数据库中->记录登录状态操作
        if (entity instanceof ResponseUserEntity){
            //登录或注册返回->保存到本地操作
            ResponseUserEntity responseUserEntity = (ResponseUserEntity) entity;
            if (responseUserEntity.getValues()!=null)
                App.getInstance().getDaoSession().deleteAll(UserEntity.class);
            App.getInstance().getDaoSession().insert(responseUserEntity.getValues());
        }
        v.refreshView(entity);
    }
}
