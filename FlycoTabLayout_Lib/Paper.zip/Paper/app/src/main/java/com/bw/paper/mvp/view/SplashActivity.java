package com.bw.paper.mvp.view;

import android.view.View;

import com.bw.paper.R;
import com.bw.paper.handler.TimerHandler;
import com.bw.paper.mvp.base.view.BaseActivity;
import com.bw.paper.mvp.contract.SplashContract;
import com.bw.paper.mvp.di.DaggerSplashComponent;
import com.bw.paper.mvp.di.SplashModules;
import com.bw.paper.mvp.presenter.SplashPresenter;
import com.bw.paper.thread.TimerThread;
import com.bw.paper.utils.LogUtils;

public class SplashActivity extends BaseActivity<SplashPresenter>implements SplashContract.ISplashView , TimerHandler.TimerCallBack {
    @Override
    public View addStatusView() {
        return f(R.id.splash_linear);
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_splash;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {
        p.requestToken();
    }

    @Override
    public void inject() {
        DaggerSplashComponent.builder().splashModules(new SplashModules(this)).build()
                .injectSplash(this);
    }

    @Override
    public void refresh() {
        LogUtils.show("SplashPresenter->onNext");
        new TimerThread(new TimerHandler(this::callBack)).start();
    }

    @Override
    public void callBack() {
        startPage(FrameActivity.class);
        finish();
    }
}
