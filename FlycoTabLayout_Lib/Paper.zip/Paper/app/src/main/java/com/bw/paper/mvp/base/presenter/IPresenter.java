package com.bw.paper.mvp.base.presenter;

import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;

//Presenter 层的顶层接口
//使用lifecycle框架实现presenter下方法与activity或fragment生命周期绑定
public interface IPresenter extends LifecycleObserver {

    @OnLifecycleEvent(value = Lifecycle.Event.ON_DESTROY)
    void onDestrory();

}
