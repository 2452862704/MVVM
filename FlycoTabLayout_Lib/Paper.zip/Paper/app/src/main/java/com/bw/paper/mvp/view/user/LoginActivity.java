package com.bw.paper.mvp.view.user;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bw.paper.R;
import com.bw.paper.action.BroadAction;
import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.view.BaseActivity;
import com.bw.paper.mvp.contract.LoginContract;
import com.bw.paper.mvp.contract.UserContract;
import com.bw.paper.mvp.di.DaggerLoginComponent;
import com.bw.paper.mvp.di.LoginModules;
import com.bw.paper.mvp.model.HttpCode;
import com.bw.paper.mvp.model.entity.ResponseUserEntity;
import com.bw.paper.mvp.presenter.LoginPresenter;
import com.bw.paper.mvp.presenter.UserPresenter;
import com.bw.paper.utils.ToastUtils;

public class LoginActivity extends BaseActivity<LoginPresenter>implements
        LoginContract.ILoginView,View.OnClickListener{

    private ImageView head_back_img;
    private EditText login_phone_edt,login_pwd_edt;
    private Button login_btn;
    private TextView login_register_tv;

    @Override
    public View addStatusView() {
        return f(R.id.login_linear);
    }

    @Override
    public int bindLayout() {
        return R.layout.activity_login;
    }

    @Override
    public void initView() {
        head_back_img = f(R.id.head_back_img);
        login_phone_edt = f(R.id.login_phone_edt);
        login_pwd_edt = f(R.id.login_pwd_edt);
        login_btn = f(R.id.login_btn);
        login_register_tv = f(R.id.login_register_tv);
        head_back_img.setOnClickListener(this::onClick);
        login_register_tv.setOnClickListener(this::onClick);
        login_btn.setOnClickListener(this::onClick);
    }

    @Override
    public void initData() {

    }

    @Override
    public void inject() {
        DaggerLoginComponent.builder().loginModules(new LoginModules(this))
                .build().injectLogin(this);
    }

    @Override
    public void refreshView(BaseEntity entity) {
        ResponseUserEntity responseUserEntity = (ResponseUserEntity) entity;
        Intent intent = new Intent();
        intent.setAction(BroadAction.UPDATEUSERACTION);
        intent.putExtra("userValues",responseUserEntity.getValues());
        sendBroadcast(intent);
        finish();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (R.id.head_back_img == id){
            finish();
        }else if (R.id.login_btn == id){
            if (login_phone_edt.getText()==null){
                ToastUtils.showMsg("手机号为空");
                return;
            }
            if (login_pwd_edt.getText() == null){
                ToastUtils.showMsg("密码为空");
                return;
            }
            p.requestLogin(Long.valueOf(login_phone_edt.getText().toString()),login_pwd_edt.getText().toString(),
                    HttpCode.LOGINCODE);
        }else if (R.id.login_register_tv == id){
            startPage(RegisterActivity.class);
            finish();
        }
    }
}
