//今日完成目标:首页新闻列表;
新闻列表数据使用技术点: 上下拉刷新逻辑->由于项目中存在多个列表->都存在上下拉刷新操作
                       ->逻辑复用->在model层请求时->由于列表界面中具有banner 以及列表
                       接口数据->一个model中存在同时请求2个接口->presenter层实现了观察者接口
                       观察者接口关联的异步任务->BaseEntity->model层返回被观察者类型必须为baseEntity
                       ->观察者与被观察者任务类型相同才可订阅->所以使用rxjava操作符map;
                       ->列表界面中有多个接口进行请求->使用rxjava操作符merge(合并操作符)
                       ->多个异步任务整合为一个异步任务->每个子任务请求成功回调到观察者的onNext中
                       ->界面中无论多少个接口通过合并操作，只绑定到一个观察者中进行处理;
                       ->上下拉刷新->分页数据请求->page页数->下拉刷新时page =1,上拉记载page+1；
                       ->其余请求参数不变->page切换改变数据与activity无任何关联关系
                       ->presenter下进行公共处理->逻辑复用
新闻列表界面实现:NewsFragment->xml
                             协调者 
                               AppBarLayout
                                   <可被折叠布局>
                                   <flycotablayout>吸顶
                               AppBarLayout
                               ViewPager->切换的为fragment
              ContentNewsFragment->smartrefreshLayout
                                     Recyclerview
                                   smartrefrehlayout 
                                                                                   