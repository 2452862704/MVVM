package com.bw.paper.mvp.di;

import com.bw.paper.mvp.contract.SplashContract;
import com.bw.paper.mvp.model.SplashModel;

import dagger.Module;
import dagger.Provides;

@Module
public class SplashModules {

    private SplashContract.ISplashView iView;

    public SplashModules(SplashContract.ISplashView iView){
        this.iView = iView;
    }

    @Provides
    public SplashContract.ISplashView providerIView(){
        return iView;
    }

    @Provides
    public SplashContract.ISplashModel providerIModel(SplashModel model){
        return model;
    }

}
