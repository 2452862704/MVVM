package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;

public class BannerEntity extends BaseEntity {

    public String values;

}
