package com.bw.paper.mvp.base.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bw.paper.mvp.base.presenter.IPresenter;
import com.bw.paper.utils.ToastUtils;
import com.bw.paper.widget.LoadDialog;

import javax.inject.Inject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseVpFragment <P extends IPresenter> extends Fragment implements IView,IFragment{

    @Inject
    protected P p;
    protected View rootView;//当前fragment根结点视图
    protected LoadDialog loadDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(bindLayout(),container,false);
        initView();
        init();
        return rootView;
    }

    private void init(){
        inject();
        getLifecycle().addObserver(p);
        initData();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getLifecycle().removeObserver(p);
    }

    public <T extends View> T f(int id){
        return rootView.findViewById(id);
    }

    @Override
    public void startPage(Bundle bundle, Class clazz) {
        Intent intent = new Intent(getActivity(),clazz);
        if (bundle!=null)
            intent.putExtras(bundle);
        getActivity().startActivity(intent);
    }

    public void startPage(Class clazz) {
        startPage(null,clazz);
    }

    @Override
    public void showDialog() {
        loadDialog.show();
    }

    @Override
    public void hideDialog() {
        loadDialog.dismiss();
    }

    @Override
    public void showMsg(String msg) {
        ToastUtils.showMsg(msg);
    }
}
