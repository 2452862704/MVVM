package com.bw.paper.mvp.di;

import com.bw.paper.mvp.contract.LREContract;
import com.bw.paper.mvp.model.LREModel;

import dagger.Module;
import dagger.Provides;

@Module
public class LREModules {

    private LREContract.ILREView ilreView;

    public LREModules(LREContract.ILREView ilreView){
        this.ilreView = ilreView;
    }

    @Provides
    public LREContract.ILREView providerView(){
        return ilreView;
    }

    @Provides
    public LREContract.ILREModel providerModel(LREModel model){
        return model;
    }


}
