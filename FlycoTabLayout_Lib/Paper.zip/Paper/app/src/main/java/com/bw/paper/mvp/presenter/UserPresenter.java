package com.bw.paper.mvp.presenter;

import android.database.sqlite.SQLiteDatabase;

import com.bw.paper.App;
import com.bw.paper.R;
import com.bw.paper.db.DaoMaster;
import com.bw.paper.db.DaoSession;
import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;
import com.bw.paper.mvp.contract.UserContract;
import com.bw.paper.mvp.model.entity.UserEntity;
import com.bw.paper.mvp.model.entity.UserItemEntity;
import com.bw.paper.mvp.model.entity.UserMenuEntity;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import io.reactivex.annotations.NonNull;

public class UserPresenter extends BasePresenter<UserContract.IUserModel, UserContract.IUserView> {

    @Inject
    public UserPresenter(UserContract.IUserModel iUserModel, UserContract.IUserView iUserView) {
        super(iUserModel, iUserView);
    }

    //初始化数据方法
    public void initData(){
        List<UserMenuEntity> menues = new ArrayList<>();
        menues.add(new UserMenuEntity(R.drawable.res_icon7_274,"消息",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_275,"收藏",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_277,"评论",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_276,"历史",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_276,"关注",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_279,"下载",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_280,"公益",null));
        menues.add(new UserMenuEntity(R.drawable.res_icon7_281,"问政",null));
        v.refreshMenu(menues);
        List<UserItemEntity>itemes = new ArrayList<>();
        itemes.add(new UserItemEntity("积分商城",null));
        itemes.add(new UserItemEntity("夜间模式",null));
        itemes.add(new UserItemEntity("意见反馈",null));
        itemes.add(new UserItemEntity("更多设置",null));
        v.refreshItemes(itemes);

    }

    @Override
    public void onNext(@NonNull BaseEntity entity) {

    }
}
