package com.bw.paper.mvp.di;

import com.bw.paper.mvp.view.FrameActivity;

import dagger.Component;

@Component(modules = FrameModules.class)
public interface FrameComponent {
    void inject(FrameActivity activity);
}
