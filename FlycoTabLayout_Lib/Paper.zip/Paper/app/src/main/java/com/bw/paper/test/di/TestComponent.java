package com.bw.paper.test.di;

import com.bw.paper.test.TestActivity;

import dagger.Component;

@Component(modules = Modeles.class)
public interface TestComponent {

    void inject(TestActivity activity);

}
