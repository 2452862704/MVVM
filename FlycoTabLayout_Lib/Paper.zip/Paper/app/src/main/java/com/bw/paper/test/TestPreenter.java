package com.bw.paper.test;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.presenter.BasePresenter;

import javax.inject.Inject;

import io.reactivex.annotations.NonNull;

public class TestPreenter extends BasePresenter<TestContract.TestModelImpl, TestContract.TestViewImpl> {
    @Inject
    public TestPreenter(TestContract.TestModelImpl testModel, TestContract.TestViewImpl testView) {
        super(testModel, testView);
    }

    @Override
    public void onNext(@NonNull BaseEntity baseEntity) {

    }
}
