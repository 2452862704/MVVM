package com.bw.paper.mvp.view.user.adapter;

import com.bw.paper.R;
import com.bw.paper.mvp.model.entity.UserMenuEntity;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;

import org.jetbrains.annotations.NotNull;

public class UserMenuAdapter extends BaseQuickAdapter<UserMenuEntity, BaseViewHolder> {
    public UserMenuAdapter() {
        super(R.layout.item_user_menu);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder baseViewHolder, UserMenuEntity userMenuEntity) {
        baseViewHolder.setText(R.id.user_menu_item_name,userMenuEntity.name);
        baseViewHolder.setImageResource(R.id.user_menu_icon,userMenuEntity.imgId);
    }
}
