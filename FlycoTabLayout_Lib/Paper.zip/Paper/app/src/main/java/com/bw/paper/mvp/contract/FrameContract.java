package com.bw.paper.mvp.contract;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.bw.paper.mvp.base.model.IModel;
import com.bw.paper.mvp.base.view.IView;

import java.util.Map;

import io.reactivex.Observable;

public interface FrameContract {

    interface IFrameModel extends IModel{
        Observable<BaseEntity>request(Map<String,Object>map);
    }

    interface IFrameView extends IView{
        //当有新版本更新时->P层通过回调接口IFrameView->
        //传递回三方更新框架upgrade更新信息以及下载地址
        void refresh(Map<String,Object>resultMap);
    }


}
