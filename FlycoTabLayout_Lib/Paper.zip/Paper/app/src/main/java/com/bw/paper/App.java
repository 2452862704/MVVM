package com.bw.paper;

import android.database.sqlite.SQLiteDatabase;

import com.bw.paper.db.DaoMaster;
import com.bw.paper.db.DaoSession;

import androidx.multidex.MultiDexApplication;

public class App extends MultiDexApplication {

    private static App instance;
    public static DaoSession mSession;
    public static App getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        initDb();
    }

    private void initDb() {
        // 1、获取需要连接的数据库
        DaoMaster.DevOpenHelper devOpenHelper = new DaoMaster.DevOpenHelper(this, "paper.db");
        SQLiteDatabase db = devOpenHelper.getWritableDatabase();
        // 2、创建数据库连接
        DaoMaster daoMaster = new DaoMaster(db);
        // 3、创建数据库会话
        mSession = daoMaster.newSession();
    }

    // 供外接使用
    public DaoSession getDaoSession() {
        return mSession;
    }
}
