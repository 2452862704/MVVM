package com.bw.paper.mvp.base.view;
//view层与presenter层交互顶层接口
public interface IView {
    void showDialog();
    void hideDialog();
    void showMsg(String msg);
}
