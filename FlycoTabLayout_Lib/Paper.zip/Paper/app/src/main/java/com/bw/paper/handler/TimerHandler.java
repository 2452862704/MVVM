package com.bw.paper.handler;

import android.os.Handler;
import android.os.Message;

import java.lang.ref.WeakReference;

import androidx.annotation.NonNull;

public class TimerHandler extends Handler {

    private WeakReference<TimerCallBack>weakReference;

    public TimerHandler(TimerCallBack callBack){
        weakReference = new WeakReference<>(callBack);
    }

    @Override
    public void handleMessage(@NonNull Message msg) {
        super.handleMessage(msg);
        weakReference.get().callBack();
    }

    public interface TimerCallBack{
        void callBack();
    }

}
