package com.bw.paper.mvp.model.entity;

import com.bw.paper.mvp.base.model.BaseEntity;
import com.google.gson.Gson;

public class ResponseUserEntity extends BaseEntity {

    public String values;

    public UserEntity getValues(){
        if (values.isEmpty())
            return null;
        UserEntity entity = new Gson().fromJson(values,UserEntity.class);
        return entity;
    }
}
